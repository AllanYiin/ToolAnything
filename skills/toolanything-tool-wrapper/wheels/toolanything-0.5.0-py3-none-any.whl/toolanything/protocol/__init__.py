"""Protocol layer interfaces."""
