"""ToolManager: 管理工具註冊、Schema 匯出與統一呼叫入口。"""
from __future__ import annotations

from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence

from .credentials import CredentialResolver
from .http_tools import register_http_tool
from .model_runtime import ModelHookRegistry, ModelSessionCache
from .model_tools import register_model_tool
from .models import ToolSpec
from .registry import ToolRegistry
from .failure_log import FailureLogManager
from .source_specs import HttpSourceSpec, ModelSourceSpec, SqlSourceSpec
from .sql_connections import SQLConnectionProvider
from .sql_tools import register_sql_tool
from ..runtime.concurrency import ParallelOptions, RetryPolicy, parallel_map_async


class ToolManager:
    """封裝工具註冊與執行策略的高階介面。"""

    def __init__(
        self,
        registry: ToolRegistry | None = None,
        *,
        default_adapters: Iterable[str] = ("openai", "mcp"),
        strict: bool = True,
        failure_log: FailureLogManager | None = None,
    ) -> None:
        self.registry = registry or ToolRegistry.global_instance()
        self.default_adapters = tuple(default_adapters)
        self.strict = strict
        self.failure_log = failure_log
        # 讓 decorator 有機會讀取預設 adapter 設定。
        self.registry.default_adapters = self.default_adapters  # type: ignore[attr-defined]

    def register(self, func: Callable[..., Any] | None = None, **tool_kwargs: Any):
        """同時支援 decorator 與手動註冊的介面。"""

        def decorator(fn: Callable[..., Any]):
            spec = ToolSpec.from_function(
                fn,
                name=tool_kwargs.get("name"),
                description=tool_kwargs.get("description"),
                adapters=tool_kwargs.get("adapters", self.default_adapters),
                tags=tool_kwargs.get("tags"),
                strict=tool_kwargs.get("strict", self.strict),
                metadata=tool_kwargs.get("metadata"),
            )
            self.registry.register(spec)
            return fn

        if func is not None:
            return decorator(func)

        return decorator

    def register_http_tool(
        self,
        source: HttpSourceSpec,
        *,
        credential_resolver: CredentialResolver | None = None,
    ) -> ToolSpec:
        return register_http_tool(
            self.registry,
            source,
            credential_resolver=credential_resolver,
        )

    def register_sql_tool(
        self,
        source: SqlSourceSpec,
        *,
        connection_provider: SQLConnectionProvider | None = None,
    ) -> ToolSpec:
        return register_sql_tool(
            self.registry,
            source,
            connection_provider=connection_provider,
        )

    def register_model_tool(
        self,
        source: ModelSourceSpec,
        *,
        session_cache: ModelSessionCache | None = None,
        hook_registry: ModelHookRegistry | None = None,
    ) -> ToolSpec:
        return register_model_tool(
            self.registry,
            source,
            session_cache=session_cache,
            hook_registry=hook_registry,
        )

    def _filter_specs(self, adapter: str) -> List[ToolSpec]:
        return [
            spec
            for spec in self.registry.list()
            if spec.adapters is None or adapter in spec.adapters
        ]

    def get_schema(self, adapter: str) -> List[Dict[str, Any]]:
        adapter_lower = adapter.lower()
        specs = self._filter_specs(adapter_lower)

        if adapter_lower == "openai":
            return [spec.to_openai() for spec in specs]
        if adapter_lower == "mcp":
            return [spec.to_mcp() for spec in specs]

        raise ValueError(f"未知 adapter: {adapter}")

    async def invoke(
        self,
        name: str,
        args: Dict[str, Any],
        *,
        context: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """統一的 async 呼叫入口，兼容同步函數。"""

        # context 可作為未來擴充，暫不強制注入。
        context = context or {}
        return await self.registry.invoke_tool_async(
            name,
            arguments=args,
            user_id=context.get("user_id"),
            state_manager=context.get("state_manager"),
            failure_log=self.failure_log,
        )

    async def invoke_many(
        self,
        name: str,
        args_list: Sequence[Dict[str, Any]],
        *,
        context: Optional[Dict[str, Any]] = None,
        concurrency: int = 8,
        preserve_order: bool = True,
        max_retries: int = 0,
        rate_limit_per_minute: Optional[int] = None,
    ) -> List[Any]:
        """
        Batch invoke the same tool with parallel execution.

        v1 strategy:
        - keep behavior consistent with invoke()
        - concurrency / retry / rate limit as execution options
        """

        policy = RetryPolicy(max_retries=max_retries)
        options = ParallelOptions(
            concurrency=concurrency,
            preserve_order=preserve_order,
            retry_policy=policy,
            rate_limit_per_minute=rate_limit_per_minute,
        )

        async def _one(args: Dict[str, Any]) -> Any:
            return await self.invoke(name, args, context=context)

        return await parallel_map_async(list(args_list), _one, options=options)
